package pl.umk.mat.planner.types;

public enum groupType {
    WYKLAD,
    LAB,
    NIEST
}
