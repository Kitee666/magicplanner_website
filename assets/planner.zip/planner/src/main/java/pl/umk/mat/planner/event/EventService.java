package pl.umk.mat.planner.event;

public class EventService {

    public String test(){
        return "test";
    }
}
