package pl.umk.mat.planner.connector;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ConnectorRepository extends JpaRepository<Connector, Long> {
}